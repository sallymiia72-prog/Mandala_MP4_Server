# Soul Mandala Server Render — 60 секунд

Сервер получает дату рождения и создаёт готовый MP4 без записи экрана и без конвертации на телефоне.

## Параметры
- 60 секунд
- 720 × 900
- 24 fps
- H.264 + AAC
- совместимость с WhatsApp, Telegram, Android и iPhone

## Настройки Render
- Build Command: `npm install`
- Start Command: `node server.js`
- Root Directory: пусто
- Plan: Free для теста

## Проверка
Откройте `/health`; ответ должен быть `{"ok":true}`.

## API
POST `/render`

```json
{"birthDate":"1969-05-22","duration":60}
```
